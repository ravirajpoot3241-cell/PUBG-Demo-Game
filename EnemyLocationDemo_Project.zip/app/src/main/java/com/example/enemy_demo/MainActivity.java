package com.example.enemy_demo;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.Gravity;
import android.graphics.Typeface;

public class MainActivity extends Activity {
    private MapView map;
    private TextView status;
    private boolean showEnemies = true;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18, 18, 18, 18);
        root.setBackgroundColor(Color.rgb(18, 27, 36));

        TextView title = new TextView(this);
        title.setText("ENEMY LOCATION DEMO");
        title.setTextColor(Color.WHITE);
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, 56));

        TextView note = new TextView(this);
        note.setText("Practice map • Fictional enemy markers only\nNot connected to PUBG or any live match");
        note.setTextColor(Color.LTGRAY);
        note.setTextSize(13);
        note.setGravity(Gravity.CENTER);
        root.addView(note, new LinearLayout.LayoutParams(-1, 52));

        map = new MapView();
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, 0, 1);
        mp.setMargins(0, 12, 0, 12);
        root.addView(map, mp);

        status = new TextView(this);
        status.setText("Demo enemies: 3 • Tap the button to hide/show");
        status.setTextColor(Color.WHITE);
        status.setGravity(Gravity.CENTER);
        root.addView(status, new LinearLayout.LayoutParams(-1, 42));

        Button toggle = new Button(this);
        toggle.setText("HIDE / SHOW ENEMIES");
        toggle.setOnClickListener(v -> {
            showEnemies = !showEnemies;
            map.invalidate();
            status.setText(showEnemies ? "Demo enemies: 3 • Fictional markers" : "Demo enemies hidden");
        });
        root.addView(toggle, new LinearLayout.LayoutParams(-1, 56));

        setContentView(root);
    }

    private class MapView extends View {
        Paint p = new Paint(3);
        MapView() { super(MainActivity.this); setBackgroundColor(Color.rgb(47, 77, 62)); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w = getWidth(), h = getHeight();
            p.setColor(Color.rgb(75, 105, 78)); c.drawRect(0,0,w,h,p);
            p.setColor(Color.rgb(104, 123, 79));
            c.drawOval(w*.06f,h*.08f,w*.43f,h*.34f,p);
            c.drawOval(w*.55f,h*.52f,w*.94f,h*.86f,p);
            p.setColor(Color.rgb(92, 112, 119));
            c.drawRoundRect(w*.18f,h*.39f,w*.82f,h*.49f,18,18,p);
            c.drawRoundRect(w*.47f,h*.12f,w*.56f,h*.91f,18,18,p);
            p.setColor(Color.rgb(194, 184, 145));
            c.drawCircle(w*.24f,h*.22f,7,p); c.drawCircle(w*.74f,h*.69f,8,p);
            c.drawCircle(w*.35f,h*.74f,6,p);
            p.setColor(Color.WHITE); p.setTextSize(14);
            c.drawText("TRAINING MAP (DEMO)", 16, 26, p);
            // player marker
            p.setColor(Color.rgb(64, 180, 255));
            c.drawCircle(w*.50f,h*.56f,14,p);
            p.setColor(Color.WHITE); c.drawCircle(w*.50f,h*.56f,5,p);
            if (showEnemies) {
                drawEnemy(c,w*.24f,h*.40f,"E1");
                drawEnemy(c,w*.78f,h*.30f,"E2");
                drawEnemy(c,w*.68f,h*.78f,"E3");
            }
            p.setColor(Color.WHITE); p.setTextSize(12);
            c.drawText("YOU", w*.50f-12, h*.56f+32, p);
        }
        void drawEnemy(Canvas c, float x, float y, String label) {
            p.setColor(Color.rgb(235, 55, 65)); c.drawCircle(x,y,17,p);
            p.setColor(Color.WHITE); p.setTextSize(11); p.setTypeface(Typeface.DEFAULT_BOLD);
            c.drawText(label,x-8,y+4,p); p.setTypeface(Typeface.DEFAULT);
        }
    }
}
